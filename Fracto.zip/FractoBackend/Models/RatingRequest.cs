public class RatingRequest
{
    public int DoctorId { get; set; }
    public int UserId { get; set; }
    public int RatingValue { get; set; }
    public string Comment { get; set; }
}
