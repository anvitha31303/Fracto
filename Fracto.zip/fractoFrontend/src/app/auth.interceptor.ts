import { HttpInterceptorFn, HttpRequest, HttpHandlerFn, HttpEvent, HttpClient } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from './services/auth.service';
import { catchError, switchMap, throwError, Observable } from 'rxjs';
import { environment } from '../environments/environment';

export const authInterceptor: HttpInterceptorFn = (req: HttpRequest<any>, next: HttpHandlerFn): Observable<HttpEvent<any>> => {
  const auth = inject(AuthService);
  const http = inject(HttpClient);

  // Add Authorization header if token exists
  const token = auth.getToken();
  if (token) {
    req = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
  }

  return next(req).pipe(
    catchError((err) => {
      if (err.status === 401) {
        // Optional: refresh token logic
        return http.post<{ token: string }>(`${environment.apiUrl}/User/refresh-token`, {}).pipe(
          switchMap((res) => {
            auth.setSession(res.token, auth.getUsername(), auth.getRole(), auth.getProfileImage());
            const newReq = req.clone({ setHeaders: { Authorization: `Bearer ${res.token}` } });
            return next(newReq);
          })
        );
      }
      return throwError(() => err);
    })
  );
};
