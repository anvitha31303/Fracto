import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class SpecializationService {
 private baseUrl = 'http://localhost:5189/api/Specialization';

  constructor(private http: HttpClient, private auth: AuthService) {}

  private getHeaders() {
    const token = this.auth.getToken();
    return { headers: new HttpHeaders({ Authorization: `Bearer ${token}` }) };
  }

  getSpecializations(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl, this.getHeaders());
  }

  addSpecialization(spec: any): Observable<any> {
    return this.http.post(this.baseUrl, spec, this.getHeaders());
  }
  deleteSpecialization(id: number) {
  return this.http.delete(`${environment.apiUrl}/Specialization/${id}`);
}

}
