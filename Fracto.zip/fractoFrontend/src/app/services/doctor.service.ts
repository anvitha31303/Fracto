import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

export interface Doctor {
  doctorId: number;
  name: string;
  city: string;
  rating: number;
  specialization?: { specializationId: number; specializationName: string };
}

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  private baseUrl = `${environment.apiUrl}/Doctor`;

  constructor(private http: HttpClient, private auth: AuthService) {}

  private getHeaders() {
    const token =this.auth.getToken();
    return { headers: new HttpHeaders({ Authorization: `Bearer ${token}` }) };
  }

  getDoctors(filters?: {
    name?: string;
    city?: string;
    specializationId?: number;
    minRating?: number;
  }): Observable<Doctor[]> {
    let params = new HttpParams();
    if (filters?.name) params = params.set('name', filters.name);
    if (filters?.city) params = params.set('city', filters.city);
    if (filters?.specializationId) params = params.set('specializationId', filters.specializationId);
    if (filters?.minRating) params = params.set('minRating', filters.minRating);

    return this.http.get<Doctor[]>(this.baseUrl, { params });
  }

  getSpecializations(): Observable<any[]> {
    return this.http.get<any[]>(`${environment.apiUrl}/Specialization`);
  }

  addDoctor(doctor: any): Observable<any> {
    return this.http.post(this.baseUrl, doctor, this.getHeaders());
  }

  updateDoctor(id: number, doctor: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, doctor, this.getHeaders());
  }

  deleteDoctor(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, this.getHeaders());
  }

  getDoctorRatings(doctorId: number) {
    return this.http.get(`${this.baseUrl}/Rating/doctor/${doctorId}`);
  }

  addRating(data: any) {
    return this.http.post(`${this.baseUrl}/Rating`, data);
  }
}
