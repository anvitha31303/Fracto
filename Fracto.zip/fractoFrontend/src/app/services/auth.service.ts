import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private token: string | null = null;
  private username: string = '';
  private role: string = '';
  private profileImage?: string; // use undefined instead of null
constructor(private http: HttpClient) {}
  setSession(token: string, username: string, role: string, profileImage?: string) {
    this.token = token;
    this.username = username;
    this.role = role;
    this.profileImage = profileImage;
  }

  clearSession() {
    this.token = null;
    this.username = '';
    this.role = '';
    this.profileImage = undefined;
  }

  getToken(): string | null { return this.token; }
  getUsername(): string { return this.username; }
  getRole(): string { return this.role; }
  getProfileImage(): string | undefined { return this.profileImage; }

  isLoggedIn(): boolean { return !!this.token; }
  register(username: string, password: string): Observable<any> {
    const body = { username, password };
    return this.http.post(`${environment.apiUrl}/User/register`, body);
  }
}
