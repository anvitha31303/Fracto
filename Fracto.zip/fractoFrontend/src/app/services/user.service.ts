import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class UserService {
 private baseUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  login(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/User/login`, data);
  }

  register(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/User/register`, data);

  }
   // 👥 USERS CRUD (Admin only)
  getAllUsers(): Observable<any> {
    return this.http.get(`${this.baseUrl}/User/all`);
  }

  updateUser(id: number, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/User/${id}`, data);
  }

  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/User/${id}`);
  }

  // 👤 Profile
  getMyProfile(): Observable<any> {
    return this.http.get(`${this.baseUrl}/User/me`);
  }

  uploadProfileImage(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post(`${this.baseUrl}/User/upload-profile-image`, formData);
  }
}
