import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  
  private apiUrl = 'http://localhost:5189/api/Appointment';

  constructor(private http: HttpClient, private auth: AuthService) {}

  bookAppointment(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/book`, data);
  }

  getMyAppointments(): Observable<any> {
    return this.http.get(`${this.apiUrl}/my`);
  }

  cancelAppointment(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  // Admin
  getAllAppointments(): Observable<any> {
    return this.http.get(`${this.apiUrl}/all`);
  }

  updateStatus(id: number, status: string): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}/status`, `"${status}"`, {
      headers: { 'Content-Type': 'application/json' }
    });
    
  }
  deleteAppointment(id: number) {
  const token = this.auth.getToken();
  const headers = new HttpHeaders({
    Authorization: `Bearer ${token}`
  });

  return this.http.delete(`${environment.apiUrl}/Appointment/${id}/deleterecord`, { headers });
}

}