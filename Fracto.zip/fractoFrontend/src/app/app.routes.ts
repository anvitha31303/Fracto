import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { authGuard } from './auth.guard';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { DoctorListComponent } from './components/doctor-list/doctor-list.component';

import { SpecializationListComponent } from './components/specialization-list/specialization-list.component';

import { AppointmentBookComponent } from './components/appointment-book/appointment-book.component';
import { UserAppointmentsComponent } from './components/user-appointments/user-appointments.component';
import { AdminAppointmentsComponent } from './components/admin-appointments/admin-appointments.component';
import { ProfileComponent } from './components/profile/profile.component';
import { UsersComponent } from './components/users/users.component';
import { DoctorAddComponent } from './components/doctor-add/doctor-add.component';
import { DoctorListAdminComponent } from './components/doctor-list-admin/doctor-list-admin.component';
import { HomeComponent } from './components/home/home.component';
import { DoctorReviewsComponent } from './components/doctor-review/doctor-review.component';
export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
   
  {
    path: 'user-dashboard',
    component: UserDashboardComponent,
    canActivate: [authGuard],
    children: [
//       {
//   path: 'user-dashboard/book-appointment',
//   component: AppointmentBookComponent
// },
{ path: '', redirectTo: 'home', pathMatch: 'full' },
 { path: 'home', component: HomeComponent },
      { path: 'doctors', component: DoctorListComponent },
      { path: 'review', component: DoctorReviewsComponent },
       { path: 'book-appointment', component: AppointmentBookComponent },
      { path: 'my-appointments', component: UserAppointmentsComponent },
      { path: 'profile', component: ProfileComponent }
]},
  {
    path: 'admin-dashboard',
    component: AdminDashboardComponent,
    canActivate: [authGuard],
    children: [
           { path: '', redirectTo: 'users', pathMatch: 'full' },
    { path: 'users', component: UsersComponent }, 
      { path: 'doctors', component: DoctorListAdminComponent },
      { path: 'add-doctor', component: DoctorAddComponent },
      { path: 'specializations', component: SpecializationListComponent },

      { path: 'admin-appointments', component: AdminAppointmentsComponent },
 
    ]
  },
  { path: '**', redirectTo: 'login' }
];