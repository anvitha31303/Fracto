import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { DoctorService, Doctor } from '../../services/doctor.service';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-doctor-list-admin',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './doctor-list-admin.component.html',
  styleUrls: ['./doctor-list-admin.component.css']
})
export class DoctorListAdminComponent implements OnInit {
  doctors: Doctor[] = [];
  specializations: { specializationId: number; specializationName: string }[] = [];
  loading = true;

  filters = {
    name: '',
    city: '',
    specializationId: 0,
    minRating: 0
  };

  private searchSubject = new Subject<void>();

  constructor(private doctorService: DoctorService, private router: Router) {}

  ngOnInit(): void {
    this.loadDoctors();
    this.loadSpecializations();

    this.searchSubject.pipe(
      debounceTime(500),
      distinctUntilChanged()
    ).subscribe(() => this.loadDoctors());
  }

  loadDoctors() {
    this.loading = true;
    this.doctorService.getDoctors({
      name: this.filters.name || undefined,
      city: this.filters.city || undefined,
      specializationId: this.filters.specializationId || undefined,
      minRating: this.filters.minRating || undefined
    }).subscribe({
      next: (data: Doctor[]) => {
        this.doctors = data;
        this.loading = false;
      },
      error: (err: any) => {
        console.error('Failed to load doctors', err);
        this.loading = false;
      }
    });
  }

  loadSpecializations() {
    this.doctorService.getSpecializations().subscribe({
      next: (data: any) => this.specializations = data,
      error: (err: any) => console.error('Failed to load specializations', err)
    });
  }

  onFilterChange() {
    this.searchSubject.next();
  }

  resetFilters() {
    this.filters = { name: '', city: '', specializationId: 0, minRating: 0 };
    this.loadDoctors();
  }

  bookAppointment(doc: Doctor) {
    this.router.navigate(['/user-dashboard/book-appointment'], {
      queryParams: {
        doctorId: doc.doctorId,
        name: doc.name,
        city: doc.city,
        specialization: doc.specialization?.specializationName
      }
    });
  }

  editDoctor(doc: Doctor) {
    this.router.navigate(['/admin-dashboard/add-doctor'], {
      queryParams: {
        edit: true,
        doctorId: doc.doctorId,
        name: doc.name,
        city: doc.city,
        specializationId: doc.specialization ? doc.specialization.specializationId : 0,
        rating: doc.rating
      }
    });
  }

  deleteDoctor(id: number) {
    if (!confirm('Are you sure you want to delete this doctor?')) return;
    this.doctorService.deleteDoctor(id).subscribe({
      next: () => {
        alert('Doctor deleted successfully');
        this.loadDoctors();
      },
      error: (err) => console.error('Failed to delete doctor', err)
    });
  }

  trackByDoctorId(index: number, doctor: Doctor) {
    return doctor.doctorId;
  }
}
