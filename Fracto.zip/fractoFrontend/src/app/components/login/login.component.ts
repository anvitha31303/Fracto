import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username = '';
  password = '';
  error = '';

  constructor(private http: HttpClient, private router: Router, private authService: AuthService) {}

  login() {
    const body = { username: this.username, password: this.password };

    this.http.post(`${environment.apiUrl}/User/login`, { username: this.username, password: this.password })
  .subscribe({
    next: (res: any) => {
      // Decode token
      const payload = JSON.parse(atob(res.token.split('.')[1]));
      const username = payload.username;
      const role = payload.role;

      // Fetch profile
      const headers = { Authorization: `Bearer ${res.token}` };
      this.http.get(`${environment.apiUrl}/User/me`, { headers }).subscribe({
  next: (user: any) => {
    this.authService.setSession(
      res.token,
      username,
      role,
      user.imagePath ? `http://localhost:5189${user.imagePath}` : undefined
    );

    if (role.toLowerCase() === 'admin') {
      this.router.navigate(['/admin-dashboard']);
    } else {
      this.router.navigate(['/user-dashboard']);
    }
  }
});
    },
    error: () => alert('Invalid credentials')
  });

  }

  navigateToRegister() {
    this.router.navigate(['/register']);
  }
}
