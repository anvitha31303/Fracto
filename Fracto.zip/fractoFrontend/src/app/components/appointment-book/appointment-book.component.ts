import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-appointment-book',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './appointment-book.component.html',
  styleUrls: ['./appointment-book.component.css']
})
export class AppointmentBookComponent implements OnInit {
  doctors: any[] = [];
  availabilitySlots: any[] = [];

  appointment = {
    doctorId: 0,
    doctorName: '',
    city: '',
    specialization: '',
    appointmentDate: '',
    timeSlot: ''
  };
 modalVisible = false; 
  constructor(
    private route: ActivatedRoute,
    private http: HttpClient
  ) {}
openModal(doctor: any) {
    this.appointment = {
      doctorId: doctor.doctorId,
      doctorName: doctor.name,
      city: doctor.city,
      specialization: doctor.specialization,
      appointmentDate: '',
      timeSlot: ''
    };
    this.modalVisible = true;
  }

  closeModal() {
    this.modalVisible = false;
  }

  ngOnInit(): void {
    // ✅ Pre-fill from query params
    this.route.queryParams.subscribe(params => {
      this.appointment.doctorId = +params['doctorId'] || 0;
      this.appointment.doctorName = params['name'] || '';
      this.appointment.city = params['city'] || '';
      this.appointment.specialization = params['specialization'] || '';

      if (this.appointment.doctorId) {
        this.loadAvailability();
      }
    });
  }
loadAvailability() {
  if (!this.appointment.doctorId || !this.appointment.appointmentDate) return;

  const dateStr = this.appointment.appointmentDate; // 'YYYY-MM-DD'
  this.http.get<any[]>(`${environment.apiUrl}/Booking/doctor/${this.appointment.doctorId}/available-slots?date=${dateStr}`)
    .subscribe({
      next: (res: any[]) => this.availabilitySlots = res.map(s => ({ timeSlot: s })), // wrap in object for template
      error: (err: any) => console.error('Error loading availability', err)
    });
}

  // loadAvailability() {
  //   this.http.get(`${environment.apiUrl}/DoctorAvailability/doctor/${this.appointment.doctorId}`)

  //     .subscribe({
  //       next: (res: any) => this.availabilitySlots = res,
  //       error: (err: any) => console.error('Error loading availability', err)
  //     });
  // }

  book() {
    if (!this.appointment.doctorId || !this.appointment.appointmentDate || !this.appointment.timeSlot) {
      console.log('Appointment booked:', this.appointment);
  alert(`Appointment booked for ${this.appointment.doctorName} on ${this.appointment.appointmentDate} at ${this.appointment.timeSlot}`);
  this.closeModal();
    }

    const payload = {
      doctorId: this.appointment.doctorId,
      appointmentDate: this.appointment.appointmentDate,
      timeSlot: this.appointment.timeSlot
    };

    this.http.post(`${environment.apiUrl}/Appointment/book`, payload)
      .subscribe({
        next: () => alert('Appointment booked successfully!'),
        error: (err: any) => console.error('Error booking appointment', err)
      });
  }
}
