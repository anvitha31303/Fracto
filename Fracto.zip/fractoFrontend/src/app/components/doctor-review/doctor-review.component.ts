import { Component, Input, OnInit } from '@angular/core';
import { DoctorService } from '../../services/doctor.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-doctor-review',
   standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './doctor-review.component.html',
  styleUrl: './doctor-review.component.css'
})
export class DoctorReviewsComponent implements OnInit {
  doctorId!: number;
  reviews: any[] = [];
  averageRating: number = 0;
  newRating = { ratingValue: 0, comment: '' };

  constructor(private route: ActivatedRoute, private http: HttpClient, private auth: AuthService) {}

  ngOnInit() {
    this.doctorId = +this.route.snapshot.paramMap.get('doctorId')!;
    this.loadReviews();
  }

  loadReviews() {
    this.http.get(`${environment.apiUrl}/Rating/doctor/${this.doctorId}`)
      .subscribe((res: any) => {
        this.reviews = res.ratings;
        this.averageRating = res.averageRating;
      });
  }

  submitRating() {
    const payload = {
      doctorId: this.doctorId,
      userId: this.getLoggedInUserId(), // extract from token/localStorage
      ratingValue: this.newRating.ratingValue,
      comment: this.newRating.comment
    };

    this.http.post(`${environment.apiUrl}/Rating`, payload)
      .subscribe({
        next: () => {
          alert('✅ Rating submitted successfully!');
          this.newRating = { ratingValue: 0, comment: '' };
          this.loadReviews();
        },
        error: err => console.error('Failed to submit rating', err)
      });
  }

  getLoggedInUserId(): number {
    const token = this.auth.getToken();
    if (!token) return 0;
    const payload = JSON.parse(atob(token.split('.')[1]));
    return parseInt(payload["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"]);
  }
}
