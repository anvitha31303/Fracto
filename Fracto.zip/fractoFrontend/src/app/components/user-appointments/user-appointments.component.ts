import { Component, OnInit } from '@angular/core';
import { AppointmentService } from '../../services/appointment.service';
import { CommonModule, DatePipe } from '@angular/common';

@Component({
  selector: 'app-user-appointments',
  standalone: true,
  imports: [CommonModule],
  providers: [DatePipe],
  templateUrl: './user-appointments.component.html',
  styleUrl: './user-appointments.component.css'
})
export class UserAppointmentsComponent implements OnInit {
  appointments: any[] = [];
  loading = true;

  constructor(private appointmentService: AppointmentService) {}

  ngOnInit(): void {
    this.loadAppointments();
  }

  loadAppointments() {
    this.appointmentService.getMyAppointments().subscribe({
      next: (res: any) => {
        this.appointments = res;
        this.loading = false;
      },
      error: (err) => console.error(err)
    });
  }

  cancel(id: number) {
    if (confirm('Are you sure to cancel this appointment?')) {
      this.appointmentService.cancelAppointment(id).subscribe(() => this.loadAppointments());
    }
  }
}
