import { Component, OnInit } from '@angular/core';
import { SpecializationService } from '../../services/specialization.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-specialization-list',
  imports: [CommonModule,FormsModule],
  templateUrl: './specialization-list.component.html',
  styleUrl: './specialization-list.component.css'
})
export class SpecializationListComponent  implements OnInit {
  specializations: any[] = [];
  showAddModal = false;
  newSpecialization = '';
  constructor(private specializationService: SpecializationService) {}

  ngOnInit() {
    this.specializationService.getSpecializations().subscribe(data => {
      this.specializations = data;
      this.loadSpecializations();
    });
  }
    loadSpecializations() {
    this.specializationService.getSpecializations().subscribe({
      next: res => this.specializations = res,
      error: err => console.error('Error loading specializations', err)
    });
  }

 openAddModal() {
    this.newSpecialization = '';
    this.showAddModal = true;
  }

  closeAddModal() {
    this.showAddModal = false;
  }

  addSpecialization() {
    if (!this.newSpecialization.trim()) return;

    const newSpec = { specializationName: this.newSpecialization };
    this.specializationService.addSpecialization(newSpec).subscribe({
      next: () => {
        alert('Specialization added successfully!');
        this.loadSpecializations(); // refresh list
        this.closeAddModal();
      },
      error: err => console.error('Error adding specialization', err)
    });
  }
    deleteSpecialization(id: number) {
    if (!confirm('Are you sure you want to delete this specialization?')) return;

    this.specializationService.deleteSpecialization(id).subscribe({
      next: () => this.loadSpecializations(), // refresh list
      error: err => console.error('Error deleting specialization', err)
    });
  }
}
