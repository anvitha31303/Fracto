import { Component } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterModule, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-user-dashboard',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterModule, RouterLinkActive],
  templateUrl: './user-dashboard.component.html',
  styleUrl: './user-dashboard.component.css'
})
export class UserDashboardComponent {
  profileImageUrl: string | undefined;
  //profileImageUrl: string | null = null;
  username: string = '';
  role: string = '';
  showDropdown = false;
ngOnInit() {
  this.loadUserData();
}
  constructor(private router: Router, private auth: AuthService) {
    // 🔄 Refresh whenever localStorage changes (e.g. profile image uploaded)
    window.addEventListener('storage', () => this.loadUserData());
  }
  private loadUserData() {
  this.profileImageUrl = this.auth.getProfileImage();
  console.log('Profile Image URL:', this.profileImageUrl);
  this.username = this.auth.getUsername();
  this.role = this.auth.getRole();
}
  toggleProfileDropdown() {
    this.showDropdown = !this.showDropdown;
  }
  

  goToProfile() {
    this.router.navigate(['/user-dashboard/profile']);
  }
  logout() {
  this.auth.clearSession();
  this.router.navigate(['/login']);
}

}
