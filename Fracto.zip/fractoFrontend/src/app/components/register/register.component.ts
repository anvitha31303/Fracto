import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
@Component({
  selector: 'app-register',
   standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
username = '';
  password = '';

  constructor(private http: HttpClient, private router: Router) {}

  register() {
    const body = { username: this.username, password: this.password };

      this.http.post(`${environment.apiUrl}/User/register`, body)
    
      .subscribe({
        next: () => {
          alert('Registration successful!');
          this.router.navigate(['/login']);
        },
        error: () => alert('Registration failed')
      });
  }
  navigateToLogin() {
    this.router.navigate(['/login']);
  }
}
