import { Component, OnInit } from '@angular/core';
import { DoctorService } from '../../services/doctor.service';
import { SpecializationService } from '../../services/specialization.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-doctor-add',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './doctor-add.component.html',
  styleUrls: ['./doctor-add.component.css']
})
export class DoctorAddComponent implements OnInit {
  specializations: any[] = [];
  newDoctor = { name: '', city: '', rating: 0, specializationId: 0 };

  constructor(
    private doctorService: DoctorService,
    private specializationService: SpecializationService,
    public router: Router
  ) {}

  ngOnInit(): void {
    this.loadSpecializations();
  }

  loadSpecializations() {
    this.specializationService.getSpecializations().subscribe({
      next: (res: any) => (this.specializations = res),
      error: (err) => console.error('Failed to load specializations', err)
    });
  }

  addDoctor() {
    if (!this.newDoctor.name || !this.newDoctor.city || !this.newDoctor.rating || !this.newDoctor.specializationId) {
      alert('Please fill all fields');
      return;
    }

    this.doctorService.addDoctor(this.newDoctor).subscribe({
      next: () => {
        alert('✅ Doctor added successfully!');
        this.router.navigate(['/admin-dashboard/doctors']); // redirect back to doctor list
      },
      error: (err) => console.error('Error adding doctor', err)
    });
  }
}
