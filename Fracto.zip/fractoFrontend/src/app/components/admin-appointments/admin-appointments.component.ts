import { Component, OnInit } from '@angular/core';
import { AppointmentService } from '../../services/appointment.service';
import { CommonModule, DatePipe } from '@angular/common';

@Component({
  selector: 'app-admin-appointments',
 standalone: true,
  imports: [CommonModule],
  providers: [DatePipe],
  templateUrl: './admin-appointments.component.html',
  styleUrl: './admin-appointments.component.css'
})
export class AdminAppointmentsComponent implements OnInit {
  appointments: any[] = [];

  constructor(private appointmentService: AppointmentService) {}

  ngOnInit(): void {
    this.loadAppointments();
  }

  loadAppointments() {
    this.appointmentService.getAllAppointments().subscribe((res: any) => (this.appointments = res));
  }

  updateStatus(id: number, status: string) {
    this.appointmentService.updateStatus(id, status).subscribe(() => this.loadAppointments());
  }
  deleteAppointment(id: number) {
  if (confirm('Are you sure you want to delete this appointment?')) {
    this.appointmentService.deleteAppointment(id).subscribe({
      next: () => this.loadAppointments(),
      error: (err) => console.error('Failed to delete', err)
    });
  }
}

  }
