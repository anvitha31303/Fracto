import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../services/user.service';
declare var bootstrap: any; 
@Component({
  selector: 'app-users',
  imports: [CommonModule,FormsModule],
  templateUrl: './users.component.html',
  styleUrl: './users.component.css'
})
export class UsersComponent implements OnInit{
users: any[] = [];
  newUser = { username: '', password: '', role: 'User' };
  editingUser: any = null;

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers() {
    this.userService.getAllUsers().subscribe({
      next: (res: any) => (this.users = res),
      error: (err) => console.error('Failed to fetch users', err)
    });
  }

  addUser() {
    if (!this.newUser.username || !this.newUser.password) {
      alert('Username & password are required!');
      return;
    }
    this.userService.register(this.newUser).subscribe({
      next: () => {
        alert('User added successfully');
        this.newUser = { username: '', password: '', role: 'User' };
        this.loadUsers();
      },
      error: (err) => console.error('Failed to add user', err)
    });
  }

  editUser(user: any) {
    this.editingUser = { ...user };
  }
openEditModal(user: any) {
    this.editingUser = { ...user };
    const modal = new bootstrap.Modal(document.getElementById('editUserModal'));
    modal.show();
  }

  saveEdit() {
    if (!this.editingUser) return;

    const payload: any = {
      username: this.editingUser.username,
      role: this.editingUser.role,
      passwordHash: '...'
    };
    if (this.editingUser.password?.trim()) {
      payload.passwordHash = this.editingUser.password;
    }

    this.userService.updateUser(this.editingUser.userId, payload).subscribe({
      next: () => {
        alert('User updated successfully');
        this.editingUser = null;
        this.loadUsers();
      },
      error: (err) => console.error('Failed to update user', err)
    });
  }

  cancelEdit() {
    this.editingUser = null;
  }

  deleteUser(id: number) {
    if (!confirm('Are you sure you want to delete this user?')) return;
    this.userService.deleteUser(id).subscribe({
      next: () => {
        alert('User deleted successfully');
        this.loadUsers();
      },
      error: (err) => console.error('Failed to delete user', err)
    });
  }
}
