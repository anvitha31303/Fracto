import { Component, OnInit } from '@angular/core';
import { FileUploadService } from '../../services/file-upload.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-profile',
  standalone:true,
  imports: [CommonModule,FormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {
selectedFile: File | null = null;
  imagePreview: string | null = null;
  imageUrl: string | null = null;
user = {
    username: '',
    role: '',
    email: '',
    city: '',
    phone: ''
  };
  constructor(private fileUploadService: FileUploadService) {}

  ngOnInit(): void {
    const savedImage = sessionStorage.getItem('profileImage');
    if (savedImage) {
      this.imageUrl = `http://localhost:5189${savedImage}`;
    }
     // Load user details from sessionStorage
    this.user.username = sessionStorage.getItem('username') || '';
    this.user.role = sessionStorage.getItem('role') || '';
    this.user.email = sessionStorage.getItem('email') || '';
    this.user.city = sessionStorage.getItem('city') || '';
    this.user.phone = sessionStorage.getItem('phone') || '';
  }
  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile) {
      const reader = new FileReader();
      reader.onload = (e: any) => (this.imagePreview = e.target.result);
      reader.readAsDataURL(this.selectedFile);
    }
  }
  upload() {
    if (!this.selectedFile) {
      alert('Please select a file!');
      return;
    }
    this.fileUploadService.uploadProfileImage(this.selectedFile).subscribe({
      next: (res) => {
        console.log('Upload Response:', res);
        this.imageUrl = `http://localhost:5189${res.imagePath}`;
        sessionStorage.setItem('profileImage', res.imagePath); // ✅ store path
        window.dispatchEvent(new Event('storage'));
        alert('Upload successful!');
      },
      error: (err) => console.error(err)
    });
  }
  saveDetails() {
    // Save to sessionStorage (later you can connect to backend API)
    sessionStorage.setItem('email', this.user.email);
    sessionStorage.setItem('city', this.user.city);
    sessionStorage.setItem('phone', this.user.phone);
    alert('Profile details saved successfully!');
  }
}
