import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { DoctorService } from '../../services/doctor.service';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';

@Component({
  selector: 'app-doctor-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './doctor-list.component.html',
  styleUrl: './doctor-list.component.css'
})
export class DoctorListComponent implements OnInit {
  doctors: any[] = [];
  specializations: any[] = [];
  loading = true;

  filters = {
    name: '',
    city: '',
    specializationId: 0,
    minRating: 0
  };

  private searchSubject = new Subject<void>();

  constructor(private doctorService: DoctorService, private router: Router) {}

  ngOnInit(): void {
    this.loadDoctors();
    this.loadSpecializations();

    // 🔄 Debounce search to avoid too many API calls
    this.searchSubject.pipe(
      debounceTime(500),
      distinctUntilChanged()
    ).subscribe(() => this.loadDoctors());
  }

  // 🔹 Fetch doctors with filters
  loadDoctors() {
    this.loading = true;
    this.doctorService.getDoctors({
      name: this.filters.name || undefined,
      city: this.filters.city || undefined,
      specializationId: this.filters.specializationId || undefined,
      minRating: this.filters.minRating || undefined
    }).subscribe({
      next: (data: any) => {
        this.doctors = data;
        this.loading = false;
      },
      error: (err: any) => {
        console.error('Failed to load doctors', err);
        this.loading = false;
      }
    });
  }

  // 🔹 Fetch specializations
  loadSpecializations() {
    this.doctorService.getSpecializations().subscribe({
      next: (data: any) => (this.specializations = data),
      error: (err: any) => console.error('Failed to load specializations', err)
    });
  }

  // 🔹 Live search (triggered whenever filters change)
  onFilterChange() {
    this.searchSubject.next();
  }

  resetFilters() {
    this.filters = { name: '', city: '', specializationId: 0, minRating: 0 };
    this.loadDoctors();
  }

  bookAppointment(doc: any) {
    this.router.navigate(['/user-dashboard/book-appointment'], {
      queryParams: {
        doctorId: doc.doctorId,
        name: doc.name,
        city: doc.city,
        specialization: doc.specialization.specializationName
      }
    });
  }
}
